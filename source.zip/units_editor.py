"""
RUSE Units / Buildings / Weapons editor (tabbed).

Opened from the Mod Editor hub with a live ModProject; edits the shared ``everything.cpp`` NDF held
by the project so changes accumulate until you Save (per-window Save writes the whole project .dat).

Tabs:
  Units & Buildings — grouped by faction (Nationalite) and build menu (Factory). Edit unit stats,
                      the build menu, the upgrade chain, AND the linked weapon stats inline.
  Weapons           — every TAmmunition (the real weapon stats), labelled by the units that use it.

Weapon stats live on a shared TAmmunition reached via
  unit.WeaponDescriptor -> TWeaponDescriptor -> turret -> TMountedWeaponDescriptor -> Ammunition,
so editing a weapon affects every unit that shares that ammo.
"""
import copy
import os
import re
import sys
import tkinter as tk
from tkinter import ttk, messagebox

REPO = os.path.dirname(os.path.abspath(__file__))
if REPO not in sys.path:
    sys.path.insert(0, REPO)
from ruse_mod_engine import mod_project as mp_mod  # noqa: E402
from ruse_mod_engine import ndfbin as ndfbin_mod  # noqa: E402
from ruse_mod_engine import dic as dic_mod  # noqa: E402
from i18n import t  # noqa: E402

# ── Theme (mirrors mod_manager.py palette) ──────────────────────────────────────
_R_BG        = "#08101c"
_R_BG_PANEL  = "#0e1a2a"
_R_BG_WIDGET = "#060d18"
_R_BORDER    = "#243a5c"
_R_GOLD      = "#c8a020"
_R_GOLD_BRT  = "#e0c030"
_R_TEXT      = "#ccd8e8"
_R_TEXT_DIM  = "#3e5878"
_R_SEL_BG    = "#1a3060"
_F_MAIN = ("Courier New", 9)
_F_BOLD = ("Courier New", 9, "bold")
_F_HEAD = ("Courier New", 10, "bold")

_DESC_CLASSES = [
    ("TUniteAuSolDescriptor", "Ground", "unit"),
    ("TAvionDescriptor",      "Air",    "unit"),
    ("TInfanterieDescriptor", "Infantry", "unit"),
    ("TBatimentDescriptor",   "Building", "building"),
]

# Faction = the integer Nationalite property (US / neutral carry none).
_NATION_BY_VALUE = {1: "Germany", 2: "UK", 3: "France", 4: "Italy", 5: "USSR", 6: "Japan"}
_FACTIONS = ["All", "US", "Germany", "France", "UK", "USSR", "Italy", "Japan"]

# Build-menu category = the production building (the Factory value); confirmed vs the rusepedia.
_FACTORY_TYPE = {
    8: "Barracks", 9: "Airfield", 10: "Armor", 11: "Anti-Tank",
    12: "Prototype", 13: "Artillery & AA", 3: "Turret / Defense",
}
_TYPE_FACTORY = {v: k for k, v in _FACTORY_TYPE.items()}
_MENU_CHOICES = ["Barracks", "Armor", "Anti-Tank", "Artillery & AA", "Airfield",
                 "Prototype", "Turret / Defense"]
_CATEGORIES = ["All"] + _MENU_CHOICES + ["Buildings", "Other"]

_UPG_NONE = t("(standalone - not an upgrade)")

# kind: "scalar" | "list" (per-phase ints) | "boollist" (per-phase 0/1) | "factory" (menu dropdown)
_FIELDS = [
    (t("HP (SeuilMort)"),                  "SeuilMort",          "scalar"),
    (t("Pinned threshold (SeuilPinned)"),  "SeuilPinned",        "scalar"),
    (t("Speed (VitesseLineaire)"),         "VitesseLineaire",    "scalar"),
    (t("Combat speed (VitesseCombat)"),    "VitesseCombat",      "scalar"),
    (t("Acceleration (MaxAcceleration)"),  "MaxAcceleration",    "scalar"),
    (t("Deceleration (MaxDeceleration)"),  "MaxDeceleration",    "scalar"),
    (t("U-turn time (TempsDemiTour)"),     "TempsDemiTour",      "scalar"),
    (t("Road speed bonus (SpeedBonusOnRoad)"), "SpeedBonusOnRoad", "scalar"),
    (t("Vision range (DetectionBase)"),    "DetectionBase",      "scalar"),
    (t("Air vision (PorteeVisionVolant)"), "PorteeVisionVolant", "scalar"),
    (t("Radar signature (SignatureRadar)"), "SignatureRadar",    "scalar"),
    (t("Air attack range (PorteeAttackReflexAir)"), "PorteeAttackReflexAir", "scalar"),
    (t("Ground attack range (PorteeAttackReflexSol)"), "PorteeAttackReflexSol", "scalar"),
    (t("Build time (ProductionTime)"),     "ProductionTime",     "scalar"),
    (t("Price all phases (ProductionPrice)"), "ProductionPrice", "list"),
    (t("Build menu (Factory)"),            "Factory",            "factory"),
    (t("Menu slot (PositionInMenu)"),      "PositionInMenu",     "scalar"),
    (t("Show in menu (ShowInMenu)"),       "ShowInMenu",         "boollist"),
    (t("Upgrade price (UpgradePrice)"),    "UpgradePrice",       "scalar"),
    (t("Upgrade time (UpgradeTime)"),      "UpgradeTime",        "scalar"),
    (t("Building type (TypeBatiment)"),    "TypeBatiment",       "scalar"),
    (t("Build menu id (Menu)"),            "Menu",               "scalar"),
]

# Weapon stats (on the shared TAmmunition).
_AMMO_FIELDS = [
    (t("Damage (Puissance)"),            "Puissance",                       "scalar"),
    (t("Max range (PorteeMaximale)"),    "PorteeMaximale",                  "scalar"),
    (t("Min range (PorteeMinimale)"),    "PorteeMinimale",                  "scalar"),
    (t("Time between shots (TempsEntreDeuxTirs)"), "TempsEntreDeuxTirs",    "scalar"),
    (t("Shots per volley (NbTirParSalves)"), "NbTirParSalves",              "scalar"),
    (t("Reload between volleys (TempsEntreDeuxSalves)"), "TempsEntreDeuxSalves", "scalar"),
    (t("Dispersion (AngleDispersion)"),  "AngleDispersion",                 "scalar"),
    (t("Pin radius (RayonPinned)"),      "RayonPinned",                     "scalar"),
    (t("% direct fire (PourcentageTirDirect)"), "PourcentageTirDirect",     "scalar"),
    (t("% direct moving (PourcentageTirDirectEnMouvement)"), "PourcentageTirDirectEnMouvement", "scalar"),
    (t("Indirect fire 0/1 (TirIndirect)"), "TirIndirect",                   "scalar"),
    (t("Allow ambush 0/1 (AllowAmbushShot)"), "AllowAmbushShot",            "scalar"),
    (t("Weapon level (Level)"),          "Level",                           "scalar"),
    (t("Weapon class (Arme)"),           "Arme",                            "scalar"),
    (t("Projectile type (ProjectileType)"), "ProjectileType",               "scalar"),
]

# Numeric value types that the generic "other fields" section will expose.
_NUM_TIDS = {ndfbin_mod.T.Bool, ndfbin_mod.T.Int8, ndfbin_mod.T.Int16, ndfbin_mod.T.UInt16,
             ndfbin_mod.T.Int32, ndfbin_mod.T.UInt32, ndfbin_mod.T.Long,
             ndfbin_mod.T.Float32, ndfbin_mod.T.Float64}
# Never auto-expose these as editable (identity/reference fields handled elsewhere).
_OTHER_SKIP = {"DescriptorId", "TrackingId", "AmmunitionId", "IconeType", "Key", "Nationalite",
               "ClassNameForDebug", "UpgradeRequire", "IsUpgrade"}
_COVERED = {p for _, p, _ in _FIELDS} | _OTHER_SKIP


def _nation_from_value(raw) -> str:
    try:
        return _NATION_BY_VALUE.get(int(raw), "US")
    except (TypeError, ValueError):
        return "US"


class UnitsEditorWindow(tk.Frame):
    """Embedded as a nested in-tab view (it used to be a Toplevel) — the Mod Editor hosts it and
    provides the Back button, so it carries no window chrome of its own."""
    def __init__(self, master, project: "mp_mod.ModProject", on_change=None, default_lang="us"):
        super().__init__(master)
        self.project = project
        self._on_change = on_change
        self._name_default_lang = default_lang or "us"
        self.configure(background=_R_BG)

        self._ndf = None
        self._descs = []
        self._shown = []
        self._sel = None
        self._field_rows = []
        self._upg_combo_var = None
        self._upg_candidates = {}
        self._upg_orig = None
        self._upg_require_pidx = None
        self._upg_isup_var = None
        self._upg_isup_orig = None
        self._upg_isup_chk = None
        # weapons tab
        self._ammo = []
        self._wpn_shown = []
        self._wpn_sel = None
        self._wpn_rows = []
        self._next_ammo_id = 1000   # counter for unique ids on cloned weapons
        # unit display names live in ZZ_Win.dat baseunite.dic (per language), keyed by the
        # descriptor's NameInMenuToken (an 8-byte LocHash). Edited one language at a time.
        self._name_lang_paths = {}   # lang code -> baseunite.dic entry path (per language)
        self._name_lang_order = []   # lang codes in display order (settings default first)
        self._name_key = None        # selected unit's NameInMenuToken bytes (or None)
        self._name_var = None        # the name entry for the currently-selected language
        self._name_lang_var = None   # the language dropdown var (friendly name)
        self._name_cur_lang = None   # currently-selected language code
        self._name_pending = {}      # lang code -> typed name (accumulated until Apply)
        self._name_orig_by_lang = {}  # lang code -> original .dic name (cache, per selected unit)
        self._name_cur_lbl = None    # the dim 'current value' label (updated on language switch)

        try:
            self._ndf = project.everything()
        except Exception as e:
            messagebox.showerror(t("Units Editor"),
                                 t("Could not load the gameplay data:\n{e}", e=e), parent=self)
            self.after(10, self.destroy)
            return

        self._index_descriptors()
        self._index_weapons()
        self._index_name_dics()
        self._build_ui()
        self._apply_filter()
        self._wpn_apply_filter()

    # ── data helpers ──────────────────────────────────────────────────────────

    def _prop_index(self, class_index, prop_name):
        p = self._ndf.prop_by_name_and_class(prop_name, class_index)
        if p is None:
            p = self._ndf.prop_by_name(prop_name)
        return p.index if p else None

    def _prop_value(self, inst, prop_name):
        pidx = self._prop_index(inst.class_index, prop_name)
        return inst.get(pidx) if pidx is not None else None

    def _pname(self, prop_index):
        return (self._ndf.properties[prop_index].name
                if 0 <= prop_index < len(self._ndf.properties) else "?")

    def _nation_of_inst(self, inst):
        v = self._prop_value(inst, "Nationalite")
        return "US" if v is None else _nation_from_value(v.raw)

    def _category_of(self, inst, kind):
        if kind == "building":
            return "Buildings"
        v = self._prop_value(inst, "Factory")
        if v is None or not isinstance(v.raw, int):
            return "Other"
        return _FACTORY_TYPE.get(v.raw, "Other")

    def _name_of(self, inst):
        pidx = self._prop_index(inst.class_index, "ClassNameForDebug")
        if pidx is None:
            return ""
        v = inst.get(pidx)
        if v is None:
            return ""
        return self._ndf.get_string(v.raw) if isinstance(v.raw, int) else str(v.raw)

    # ObjRef navigation (for the weapon chain) ────────────────────────────────

    def _follow(self, val):
        if val is None or val.type_id != ndfbin_mod.T.Reference:
            return None, None
        marker, ref = val.raw
        if marker != ndfbin_mod.OBJ_REF_MARKER:
            return None, None
        oi, _cls = ref
        if 0 <= oi < len(self._ndf.instances):
            return self._ndf.instances[oi], oi
        return None, None

    def _list_refs(self, inst, substr):
        out = []
        for p in inst.props:
            if substr in self._pname(p.prop_index) and p.value.type_id == ndfbin_mod.T.List:
                for it in p.value.raw:
                    out.append(self._follow(it))
        return out

    def _ammo_for_unit(self, inst):
        """[(ammo_instance, ammo_index)] reached through the weapon chain."""
        out = []
        wd, _ = self._follow(self._prop_value(inst, "WeaponDescriptor"))
        if wd is None:
            return out
        for tur, _ in self._list_refs(wd, "Turret"):
            if tur is None:
                continue
            for mw, _ in self._list_refs(tur, "MountedWeapon"):
                if mw is None:
                    continue
                am, ai = self._follow(self._prop_value(mw, "Ammunition"))
                if am is not None and ai not in [o[1] for o in out]:
                    out.append((am, ai))
        return out

    # ── property mutation helpers (class-bound) ───────────────────────────────

    def _set_bool_prop(self, inst, name, value):
        v = self._prop_value(inst, name)
        if v is not None:
            v.raw = bool(value)
        elif value:
            p = self._ndf.prop_by_name_and_class(name, inst.class_index)
            if p is not None:
                inst.set(p.index, ndfbin_mod.NdfValue(ndfbin_mod.T.Bool, True))

    def _add_int_prop_if_missing(self, inst, name, default):
        p = self._ndf.prop_by_name_and_class(name, inst.class_index)
        if p is not None and inst.get(p.index) is None:
            inst.set(p.index, ndfbin_mod.NdfValue(ndfbin_mod.T.Int32, int(default)))

    def _remove_prop(self, inst, name):
        p = self._ndf.prop_by_name_and_class(name, inst.class_index)
        if p is not None and inst.get(p.index) is not None:
            inst.remove(p.index)

    # ── weapon duplicate / set / remove ───────────────────────────────────────
    # Only the TAmmunition is shared between units (each unit has its own WeaponDescriptor /
    # turret / mounted weapon), so cloning the ammo + repointing this unit's mounted weapon(s)
    # gives the unit a private weapon without affecting anyone else.

    def _unit_weapon_nodes(self, unit):
        """[(mounted_weapon_inst, ammo_inst, ammo_idx)] across the unit's weapon chain."""
        nodes = []
        wd, _ = self._follow(self._prop_value(unit, "WeaponDescriptor"))
        if wd is None:
            return nodes
        for tur, _ in self._list_refs(wd, "Turret"):
            if tur is None:
                continue
            for mw, _ in self._list_refs(tur, "MountedWeapon"):
                if mw is None:
                    continue
                am, ai = self._follow(self._prop_value(mw, "Ammunition"))
                nodes.append((mw, am, ai))
        return nodes

    def _clone_ammo(self, src, src_idx):
        clone = copy.deepcopy(src)
        aidp = self._prop_index(clone.class_index, "AmmunitionId")
        if aidp is not None and clone.get(aidp) is not None:
            self._next_ammo_id += 1
            clone.get(aidp).raw = self._next_ammo_id
        new_idx = len(self._ndf.instances)
        self._ndf.instances.append(clone)
        if src_idx in set(self._ndf.top_objects):   # ammo are top objects — keep the clone one too
            self._ndf.top_objects.append(new_idx)
        return clone, new_idx

    def _set_mw_ammo(self, mw, ammo_idx, ammo_cls):
        p = self._prop_index(mw.class_index, "Ammunition")
        if p is not None:
            mw.set(p, ndfbin_mod.NdfValue(ndfbin_mod.T.Reference,
                                          (ndfbin_mod.OBJ_REF_MARKER, (ammo_idx, ammo_cls))))

    def _duplicate_ammo(self):
        """Clone the selected ammo into a new ammo (own values), on the Ammo tab."""
        if self._wpn_sel is None:
            return
        clone, new_idx = self._clone_ammo(self._wpn_sel["inst"], self._wpn_sel["idx"])
        new_id = self._prop_value(clone, "AmmunitionId")
        self.project.mark_dirty("gameplay", mp_mod.EVERYTHING_PATH)
        self._index_weapons()
        self._notify()
        # re-render the Units tab so its weapon ammo dropdowns pick up the new clone
        if self._sel:
            self._keep_scroll(self._fields_frame, self._render_fields)
        self._wpn_search_var.set("")    # clear filter so the new clone is visible
        self._wpn_apply_filter()
        tgt = next((i for i, a in enumerate(self._wpn_shown) if a["idx"] == new_idx), None)
        if tgt is not None:
            self._wpn_lb.selection_clear(0, tk.END)
            self._wpn_lb.selection_set(tgt)
            self._wpn_lb.see(tgt)
            self._wpn_sel = self._wpn_shown[tgt]
            self._render_wpn_fields()
        messagebox.showinfo(
            t("Duplicate ammo"),
            t("Created Ammo #{ammo_id} (a copy). Edit it here, then assign it to "
              "a unit's weapon on the Units tab (\"Set weapon's ammo to\").",
              ammo_id=(new_id.raw if new_id else '?')), parent=self)

    def _set_one_weapon_ammo(self, mw, var):
        """Repoint a single mounted weapon to the ammo chosen in its dropdown."""
        s = var.get().lstrip("#").strip()
        a = next((a for a in self._ammo if str(a["id"]) == s), None)
        if a is None:
            return
        self._set_mw_ammo(mw, a["idx"], a["inst"].class_index)
        self._after_weapon_change()

    def _remove_weapon(self):
        if not self._sel:
            return
        unit = self._sel["inst"]
        p = self._prop_index(unit.class_index, "WeaponDescriptor")
        if p is not None and unit.get(p) is not None:
            if not messagebox.askyesno(t("Remove weapon"),
                                       t("Remove the weapon from {name} "
                                         "(it will be unable to attack)?",
                                         name=self._sel['name']), parent=self):
                return
            unit.remove(p)
            self._after_weapon_change()

    def _after_weapon_change(self):
        self.project.mark_dirty("gameplay", mp_mod.EVERYTHING_PATH)
        self._index_weapons()
        self._wpn_apply_filter()
        if self._sel:
            self._render_fields()
        self._notify()

    # ── indexing ──────────────────────────────────────────────────────────────

    def _enum_class(self, cls_name):
        cls = self._ndf.class_by_name(cls_name)
        if cls is None:
            return []
        return [(i, inst) for i, inst in enumerate(self._ndf.instances)
                if inst.class_index == cls.index]

    def _index_descriptors(self):
        self._descs = []
        for cls_name, cls_label, kind in _DESC_CLASSES:
            for idx, inst in self._enum_class(cls_name):
                name = self._name_of(inst)
                self._descs.append({
                    "inst": inst, "inst_index": idx, "name": name,
                    "nation": self._nation_of_inst(inst), "cls_label": cls_label, "kind": kind,
                    "category": self._category_of(inst, kind),
                })
        self._descs.sort(key=lambda d: (d["nation"], d["category"], d["name"].lower()))

    # ── unit display names (ZZ_Win.dat baseunite.dic, keyed by NameInMenuToken LocHash) ──────────

    def _index_name_dics(self):
        """Map each language's baseunite.dic in the loc dat (lang code -> entry path). Display order
        puts the settings default first, then the canonical language order. No-ops (name editing
        disabled) if ZZ_Win.dat isn't available."""
        self._name_lang_paths = {}
        try:
            paths = self.project.entry_paths("loc", "baseunite.dic")
        except Exception:
            paths = []
        for p in paths:
            pl = p.replace("/", "\\").lower()
            m = re.search(r"translations\\([^\\]+)\\baseunite", pl)
            code = m.group(1) if m else ("dev" if "\\dev\\" in pl else None)
            if code:
                self._name_lang_paths[code] = p
        order = [c for c, _n in dic_mod.LANGUAGES if c in self._name_lang_paths]
        order += [c for c in self._name_lang_paths if c not in order]   # any unexpected extras
        if self._name_default_lang in order:                            # default language first
            order.remove(self._name_default_lang)
            order.insert(0, self._name_default_lang)
        self._name_lang_order = order

    def _name_token(self, inst):
        """The unit's NameInMenuToken (8-byte LocHash) as bytes, or None."""
        pidx = self._prop_index(inst.class_index, "NameInMenuToken")
        if pidx is None:
            return None
        v = inst.get(pidx)
        if v is None or not isinstance(v.raw, (bytes, bytearray)):
            return None
        return bytes(v.raw)

    def _name_orig(self, lang):
        """Original (on-disk) name for the selected unit's key in `lang`, or None if absent. Cached
        per selected unit (reset in _render_name)."""
        if lang in self._name_orig_by_lang:
            return self._name_orig_by_lang[lang]
        val = None
        path = self._name_lang_paths.get(lang)
        if path and self._name_key:
            try:
                val = dic_mod.get_entry(self.project.get_raw("loc", path), self._name_key)
            except Exception:
                val = None
        self._name_orig_by_lang[lang] = val
        return val

    def _index_weapons(self):
        users = {}
        for d in self._descs:
            if d["kind"] != "unit":
                continue
            for _am, ai in self._ammo_for_unit(d["inst"]):
                users.setdefault(ai, []).append(d["name"])
        self._ammo = []
        for idx, inst in self._enum_class("TAmmunition"):
            idv = self._prop_value(inst, "AmmunitionId")
            self._ammo.append({"inst": inst, "idx": idx,
                               "id": idv.raw if idv is not None else "?",
                               "users": users.get(idx, [])})
        self._ammo.sort(key=lambda a: a["id"] if isinstance(a["id"], int) else 1 << 62)
        ids = [a["id"] for a in self._ammo if isinstance(a["id"], int)]
        self._next_ammo_id = max(ids) if ids else 1000

    # ── UI ────────────────────────────────────────────────────────────────────

    def _scrollable(self, parent):
        canvas = tk.Canvas(parent, background=_R_BG_PANEL, highlightthickness=0)
        sb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, background=_R_BG_PANEL)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        canvas.bind("<Enter>", lambda e: canvas.bind_all(
            "<MouseWheel>", lambda ev: canvas.yview_scroll(int(-ev.delta / 120), "units")))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
        inner._canvas = canvas   # so re-renders can preserve the scroll position
        return inner

    def _keep_scroll(self, frame, fn):
        """Run a re-render fn that rebuilds `frame`, restoring its scroll position after."""
        cv = getattr(frame, "_canvas", None)
        pos = cv.yview()[0] if cv is not None else None
        fn()
        if cv is not None and pos is not None:
            frame.update_idletasks()
            cv.yview_moveto(pos)

    def _build_ui(self):
        self._nb = ttk.Notebook(self)
        self._nb.pack(fill="both", expand=True, padx=4, pady=(6, 2))
        t1 = ttk.Frame(self._nb)
        t2 = ttk.Frame(self._nb)
        self._nb.add(t1, text=t("  Units & Buildings  "))
        self._nb.add(t2, text=t("  Ammo  "))
        self._build_units_tab(t1)
        self._build_weapons_tab(t2)

        bottom = tk.Frame(self, background=_R_BG)
        bottom.pack(fill="x", padx=8, pady=(0, 2))
        ttk.Button(bottom, text=t("Save mod (.dat)"), command=self._save_to_mod).pack(side="left")
        self._save_status = tk.Label(bottom, text="", background=_R_BG,
                                     foreground=_R_TEXT_DIM, font=_F_MAIN)
        self._save_status.pack(side="right")
        tk.Label(self, text=t("Apply commits the current selection's edits into the project. "
                              "“Save mod (.dat)” writes ALL accumulated changes to the mod's .dat. "
                              "Weapon stats are shared — editing one affects every unit that uses it."),
                 background=_R_BG, foreground=_R_TEXT_DIM, font=_F_MAIN, justify="left",
                 wraplength=1100).pack(fill="x", padx=8, pady=(0, 6))

    def _build_units_tab(self, parent):
        bar = tk.Frame(parent, background=_R_BG_PANEL)
        bar.pack(fill="x", padx=4, pady=(6, 4))
        tk.Label(bar, text=t("Faction:"), background=_R_BG_PANEL, foreground=_R_GOLD,
                 font=_F_BOLD).pack(side="left")
        self._faction_var = tk.StringVar(value="All")
        fac = ttk.Combobox(bar, textvariable=self._faction_var, values=_FACTIONS,
                           width=12, state="readonly")
        fac.pack(side="left", padx=(4, 10))
        fac.bind("<<ComboboxSelected>>", lambda *_: self._apply_filter())
        tk.Label(bar, text=t("Build menu:"), background=_R_BG_PANEL, foreground=_R_GOLD,
                 font=_F_BOLD).pack(side="left")
        self._type_var = tk.StringVar(value="All")
        typ = ttk.Combobox(bar, textvariable=self._type_var, values=_CATEGORIES,
                           width=15, state="readonly")
        typ.pack(side="left", padx=(4, 10))
        typ.bind("<<ComboboxSelected>>", lambda *_: self._apply_filter())
        tk.Label(bar, text=t("Search:"), background=_R_BG_PANEL, foreground=_R_GOLD,
                 font=_F_BOLD).pack(side="left")
        self._search_var = tk.StringVar()
        ttk.Entry(bar, textvariable=self._search_var, width=20).pack(side="left", padx=4)
        self._search_var.trace_add("write", lambda *_: self._apply_filter())
        self._count_lbl = tk.Label(bar, text="", background=_R_BG_PANEL,
                                   foreground=_R_TEXT_DIM, font=_F_MAIN)
        self._count_lbl.pack(side="right")

        body = tk.Frame(parent, background=_R_BG)
        body.pack(fill="both", expand=True, padx=4, pady=2)
        left = tk.Frame(body, background=_R_BG_PANEL)
        left.pack(side="left", fill="y")
        lwrap = tk.Frame(left, background=_R_BG_PANEL)
        lwrap.pack(fill="y", expand=True)
        self._lb = tk.Listbox(lwrap, width=40, activestyle="none", background=_R_BG_WIDGET,
                              foreground=_R_TEXT, selectbackground=_R_SEL_BG,
                              selectforeground=_R_GOLD_BRT, font=_F_MAIN, exportselection=False)
        self._lb.pack(side="left", fill="y", expand=True)
        sb = ttk.Scrollbar(lwrap, orient="vertical", command=self._lb.yview)
        self._lb.configure(yscrollcommand=sb.set)
        sb.pack(side="left", fill="y")
        self._lb.bind("<<ListboxSelect>>", self._on_select)

        right = tk.Frame(body, background=_R_BG_PANEL)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self._hdr = tk.Label(right, text=t("Select a unit or building"), background=_R_BG_PANEL,
                             foreground=_R_GOLD_BRT, font=_F_HEAD, anchor="w", justify="left")
        self._hdr.pack(fill="x", padx=6, pady=(4, 0))
        self._sub = tk.Label(right, text="", background=_R_BG_PANEL, foreground=_R_TEXT_DIM,
                             font=_F_MAIN, anchor="w", justify="left")
        self._sub.pack(fill="x", padx=6)
        btnrow = tk.Frame(right, background=_R_BG_PANEL)
        btnrow.pack(side="bottom", fill="x", padx=6, pady=(0, 6))
        self._apply_btn = ttk.Button(btnrow, text=t("Apply changes to this unit"),
                                     command=self._apply_edits, state="disabled")
        self._apply_btn.pack(side="left")
        self._status = tk.Label(btnrow, text="", background=_R_BG_PANEL,
                                foreground=_R_TEXT_DIM, font=_F_MAIN)
        self._status.pack(side="right")
        fwrap = tk.Frame(right, background=_R_BG_PANEL)
        fwrap.pack(fill="both", expand=True, padx=2, pady=4)
        self._fields_frame = self._scrollable(fwrap)

    def _build_weapons_tab(self, parent):
        bar = tk.Frame(parent, background=_R_BG_PANEL)
        bar.pack(fill="x", padx=4, pady=(6, 4))
        tk.Label(bar, text=t("Search ammo (id or unit):"), background=_R_BG_PANEL,
                 foreground=_R_GOLD, font=_F_BOLD).pack(side="left")
        self._wpn_search_var = tk.StringVar()
        ttk.Entry(bar, textvariable=self._wpn_search_var, width=24).pack(side="left", padx=4)
        self._wpn_search_var.trace_add("write", lambda *_: self._wpn_apply_filter())
        self._wpn_count_lbl = tk.Label(bar, text="", background=_R_BG_PANEL,
                                       foreground=_R_TEXT_DIM, font=_F_MAIN)
        self._wpn_count_lbl.pack(side="right")

        body = tk.Frame(parent, background=_R_BG)
        body.pack(fill="both", expand=True, padx=4, pady=2)
        left = tk.Frame(body, background=_R_BG_PANEL)
        left.pack(side="left", fill="y")
        lwrap = tk.Frame(left, background=_R_BG_PANEL)
        lwrap.pack(fill="y", expand=True)
        self._wpn_lb = tk.Listbox(lwrap, width=46, activestyle="none", background=_R_BG_WIDGET,
                                  foreground=_R_TEXT, selectbackground=_R_SEL_BG,
                                  selectforeground=_R_GOLD_BRT, font=_F_MAIN, exportselection=False)
        self._wpn_lb.pack(side="left", fill="y", expand=True)
        sb = ttk.Scrollbar(lwrap, orient="vertical", command=self._wpn_lb.yview)
        self._wpn_lb.configure(yscrollcommand=sb.set)
        sb.pack(side="left", fill="y")
        self._wpn_lb.bind("<<ListboxSelect>>", self._on_wpn_select)

        right = tk.Frame(body, background=_R_BG_PANEL)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self._wpn_hdr = tk.Label(right, text=t("Select an ammo"), background=_R_BG_PANEL,
                                 foreground=_R_GOLD_BRT, font=_F_HEAD, anchor="w", justify="left")
        self._wpn_hdr.pack(fill="x", padx=6, pady=(4, 0))
        self._wpn_sub = tk.Label(right, text="", background=_R_BG_PANEL, foreground=_R_TEXT_DIM,
                                 font=_F_MAIN, anchor="w", justify="left", wraplength=560)
        self._wpn_sub.pack(fill="x", padx=6)
        wbtn = tk.Frame(right, background=_R_BG_PANEL)
        wbtn.pack(side="bottom", fill="x", padx=6, pady=(0, 6))
        self._wpn_apply_btn = ttk.Button(wbtn, text=t("Apply changes to this ammo"),
                                         command=self._apply_wpn, state="disabled")
        self._wpn_apply_btn.pack(side="left")
        self._wpn_dup_btn = ttk.Button(wbtn, text=t("Duplicate this ammo"),
                                       command=self._duplicate_ammo, state="disabled")
        self._wpn_dup_btn.pack(side="left", padx=8)
        self._wpn_status = tk.Label(wbtn, text="", background=_R_BG_PANEL,
                                    foreground=_R_TEXT_DIM, font=_F_MAIN)
        self._wpn_status.pack(side="right")
        wf = tk.Frame(right, background=_R_BG_PANEL)
        wf.pack(fill="both", expand=True, padx=2, pady=4)
        self._wpn_fields_frame = self._scrollable(wf)

    # ── shared rendering ──────────────────────────────────────────────────────

    def _fmt_value(self, val, kind="scalar"):
        raw = val.raw
        if kind == "factory":
            return _FACTORY_TYPE.get(raw, str(raw)) if isinstance(raw, int) else str(raw)
        if kind == "boollist" and isinstance(raw, list):
            return ", ".join("1" if getattr(e, "raw", e) else "0" for e in raw)
        if isinstance(raw, list):
            return ", ".join(str(getattr(e, "raw", e)) for e in raw)
        return str(raw)

    def _section(self, container, title):
        tk.Label(container, text=title, anchor="w", background=_R_BG_PANEL,
                 foreground=_R_GOLD_BRT, font=_F_BOLD).pack(fill="x", padx=2, pady=(10, 2))

    # Three columns spanning the FULL width: a wrapping label pinned to the LEFT edge (column 0
    # stretches), the current-value preview, then the entry pinned to the RIGHT edge. The value
    # columns are wide enough to show full floats / short lists (the label column gives up the room).
    _VAL_W = 22         # chars: current-value preview column
    _ENT_W = 28         # chars: editable entry / combobox

    @staticmethod
    def _wrap_label(parent, text, fg):
        lab = tk.Label(parent, text=text, anchor="w", justify="left", background=_R_BG_PANEL,
                       foreground=fg, font=_F_MAIN)
        lab.grid(row=0, column=0, sticky="ew", padx=(2, 14))
        lab.bind("<Configure>", lambda e, L=lab: L.configure(wraplength=max(e.width - 4, 80)))
        return lab

    def _col_header(self, container):
        hdr = tk.Frame(container, background=_R_BG_PANEL)
        hdr.pack(fill="x", pady=(0, 2))
        hdr.grid_columnconfigure(0, weight=1)
        tk.Label(hdr, text=t("Field"), anchor="w", background=_R_BG_PANEL,
                 foreground=_R_GOLD, font=_F_BOLD).grid(row=0, column=0, sticky="w", padx=(2, 14))
        tk.Label(hdr, text=t("Current"), width=self._VAL_W, anchor="e", background=_R_BG_PANEL,
                 foreground=_R_GOLD, font=_F_BOLD).grid(row=0, column=1, sticky="e", padx=(0, 12))
        tk.Label(hdr, text=t("New value"), width=self._ENT_W, anchor="e", background=_R_BG_PANEL,
                 foreground=_R_GOLD, font=_F_BOLD).grid(row=0, column=2, sticky="e", padx=(0, 4))

    def _add_field_row(self, container, rows, label, prop, kind, val):
        row = tk.Frame(container, background=_R_BG_PANEL)
        row.pack(fill="x", pady=2)
        row.grid_columnconfigure(0, weight=1)
        self._wrap_label(row, label, _R_TEXT)
        cur = self._fmt_value(val, kind)
        tk.Label(row, text=cur[:self._VAL_W], width=self._VAL_W, anchor="e", background=_R_BG_PANEL,
                 foreground=_R_TEXT_DIM, font=_F_MAIN).grid(row=0, column=1, sticky="e", padx=(0, 12))
        var = tk.StringVar(value=cur)
        if kind == "factory":
            ttk.Combobox(row, textvariable=var, values=_MENU_CHOICES, width=self._ENT_W,
                         state="readonly").grid(row=0, column=2, sticky="e", padx=(0, 4))
        else:
            ttk.Entry(row, textvariable=var, width=self._ENT_W).grid(row=0, column=2, sticky="e", padx=(0, 4))
        rows.append((prop, kind, val, var, cur))

    def _render_group(self, container, rows, inst, specs):
        any_shown = False
        for label, prop, kind in specs:
            pidx = self._prop_index(inst.class_index, prop)
            if pidx is None:
                continue
            val = inst.get(pidx)
            if val is None:
                continue
            self._add_field_row(container, rows, label, prop, kind, val)
            any_shown = True
        return any_shown

    def _render_other(self, container, rows, inst, covered):
        """Expose every remaining numeric (Int/Float/Bool) property by its raw name."""
        shown = False
        for pvv in inst.props:
            name = self._pname(pvv.prop_index)
            if name in covered or pvv.value.type_id not in _NUM_TIDS:
                continue
            self._add_field_row(container, rows, name, name, "scalar", pvv.value)
            shown = True
        if not shown:
            tk.Label(container, text=t("(none)"), background=_R_BG_PANEL,
                     foreground=_R_TEXT_DIM, font=_F_MAIN).pack(anchor="w", padx=2)
        return shown

    # ── Units tab ───────────────────────────────────────────────────────────────

    def _apply_filter(self):
        fac = self._faction_var.get()
        cat = self._type_var.get()
        q = self._search_var.get().strip().lower()
        self._shown = []
        for d in self._descs:
            if fac != "All" and d["nation"] != fac:
                continue
            if cat != "All" and d["category"] != cat:
                continue
            if q and q not in d["name"].lower():
                continue
            self._shown.append(d)
        self._lb.delete(0, tk.END)
        for d in self._shown:
            self._lb.insert(tk.END, t("[{tag}] {name}", tag=d['cls_label'][0],
                                      name=d['name'] or t("(unnamed)")))
        self._count_lbl.configure(text=t("{shown} of {total}",
                                         shown=len(self._shown), total=len(self._descs)))
        self._clear_fields()

    def _on_select(self, _=None):
        sel = self._lb.curselection()
        if not sel:
            return
        self._sel = self._shown[sel[0]]
        self._render_fields()

    def _clear_fields(self):
        for w in self._fields_frame.winfo_children():
            w.destroy()
        self._field_rows = []
        self._upg_combo_var = None
        self._upg_candidates = {}
        self._upg_orig = None
        self._upg_require_pidx = None
        self._upg_isup_var = None
        self._upg_isup_orig = None
        self._upg_isup_chk = None
        self._sel = None
        self._apply_btn.configure(state="disabled")
        self._hdr.configure(text=t("Select a unit or building"))
        self._sub.configure(text="")
        self._status.configure(text="")

    def _render_fields(self):
        for w in self._fields_frame.winfo_children():
            w.destroy()
        self._field_rows = []
        d = self._sel
        inst = d["inst"]
        self._hdr.configure(text=d["name"] or t("(unnamed)"))
        self._sub.configure(text=t("{cls} · {nation} · {category} · "
                                   "instance #{idx}",
                                   cls=d['cls_label'], nation=d['nation'],
                                   category=d['category'], idx=d['inst_index']))

        self._render_name(inst)

        self._section(self._fields_frame, t("Unit / building stats"))
        self._col_header(self._fields_frame)
        self._render_group(self._fields_frame, self._field_rows, inst, _FIELDS)

        self._render_upgrade(inst, d)

        # Inline weapons: each mounted weapon has its OWN ammo, set per weapon.
        nodes = self._unit_weapon_nodes(inst) if d["kind"] == "unit" else []
        if nodes:
            self._section(self._fields_frame, t("Weapons — set each weapon's ammo"))
            ammo_vals = [f"#{a['id']}" for a in self._ammo]
            for wi, (mw, am, ai) in enumerate(nodes):
                idv = self._prop_value(am, "AmmunitionId") if am is not None else None
                tagv = self._prop_value(mw, "EffectTag")
                wname = (self._ndf.get_string(tagv.raw)
                         if tagv is not None and isinstance(tagv.raw, int)
                         else t("Weapon {n}", n=wi + 1))
                row = tk.Frame(self._fields_frame, background=_R_BG_PANEL)
                row.pack(fill="x", pady=2)
                row.grid_columnconfigure(0, weight=1)
                self._wrap_label(row, wname, _R_TEXT)
                tk.Label(row, text=t("ammo #{ammo_id}", ammo_id=(idv.raw if idv else '?')),
                         width=self._VAL_W, anchor="e",
                         background=_R_BG_PANEL, foreground=_R_TEXT_DIM, font=_F_MAIN
                         ).grid(row=0, column=1, sticky="e", padx=(0, 12))
                ctrl = tk.Frame(row, background=_R_BG_PANEL)
                ctrl.grid(row=0, column=2, sticky="e", padx=(0, 4))
                var = tk.StringVar(value=f"#{idv.raw}" if idv else "")
                ttk.Combobox(ctrl, textvariable=var, values=ammo_vals, width=9,
                             state="readonly").pack(side="left")
                ttk.Button(ctrl, text=t("Set ammo"),
                           command=lambda m=mw, v=var: self._set_one_weapon_ammo(m, v)
                           ).pack(side="left", padx=(4, 0))
            rm = tk.Frame(self._fields_frame, background=_R_BG_PANEL)
            rm.pack(fill="x", pady=1)
            ttk.Button(rm, text=t("Remove all weapons from this unit"),
                       command=self._remove_weapon).pack(side="left", padx=2)
            tk.Label(self._fields_frame,
                     text=t("Each weapon fires its own ammo. To make a unique weapon, duplicate an ammo "
                            "on the Ammo tab, then Set it on the weapon here. Editing a shared ammo below "
                            "affects every unit using it."),
                     background=_R_BG_PANEL, foreground=_R_TEXT_DIM, font=_F_MAIN,
                     wraplength=560, justify="left").pack(anchor="w", padx=2)
            # editable stats for each DISTINCT ammo this unit uses
            ammo_covered = {p for _, p, _ in _AMMO_FIELDS} | _OTHER_SKIP
            seen = set()
            for mw, am, ai in nodes:
                if am is None or ai in seen:
                    continue
                seen.add(ai)
                users = next((a["users"] for a in self._ammo if a["idx"] == ai), [])
                shared = (t("  (shared by {n} units)", n=len(users)) if len(users) > 1
                          else t("  (private to this unit)"))
                idv = self._prop_value(am, "AmmunitionId")
                self._section(self._fields_frame,
                              t("Ammo #{ammo_id}{shared} stats",
                                ammo_id=(idv.raw if idv else '?'), shared=shared))
                self._render_group(self._fields_frame, self._field_rows, am, _AMMO_FIELDS)
                self._render_other(self._fields_frame, self._field_rows, am, ammo_covered)

        # Catch-all: any other numeric field on the unit not shown above
        self._section(self._fields_frame, t("Other unit fields (raw)"))
        self._render_other(self._fields_frame, self._field_rows, inst, _COVERED)

        self._apply_btn.configure(state="normal")
        self._status.configure(text="")

    def _render_name(self, inst):
        """Editable in-game display name, ONE language at a time. The name lives in ZZ_Win.dat
        baseunite.dic (one per language), keyed by NameInMenuToken. A language dropdown (defaulting to
        the settings language) switches which language's name the entry shows; typed values for each
        language accumulate in _name_pending until Apply."""
        self._name_var = None
        self._name_lang_var = None
        self._name_cur_lbl = None
        self._name_cur_lang = None
        self._name_pending = {}
        self._name_orig_by_lang = {}
        self._name_key = self._name_token(inst)
        self._section(self._fields_frame, t("Display name (in-game)"))
        row = tk.Frame(self._fields_frame, background=_R_BG_PANEL)
        row.pack(fill="x", pady=2)
        row.grid_columnconfigure(0, weight=1)
        if not self._name_lang_paths:
            self._wrap_label(row, t("Name editing needs ZZ_Win.dat (not in this mod's sources)"), _R_TEXT_DIM)
            return
        if self._name_key is None:
            self._wrap_label(row, t("(this descriptor has no NameInMenuToken)"), _R_TEXT_DIM)
            return
        langs = [c for c in self._name_lang_order if self._name_orig(c) is not None]
        if not langs:
            self._wrap_label(row, t("(name not found in baseunite.dic for this unit)"), _R_TEXT_DIM)
            return
        start = self._name_default_lang if self._name_default_lang in langs else langs[0]
        self._name_cur_lang = start
        cur = self._name_orig(start) or ""

        # name row: label | current value | entry
        self._wrap_label(row, t("Unit name"), _R_TEXT)
        self._name_cur_lbl = tk.Label(row, text=cur[:self._VAL_W], width=self._VAL_W, anchor="e",
                                      background=_R_BG_PANEL, foreground=_R_TEXT_DIM, font=_F_MAIN)
        self._name_cur_lbl.grid(row=0, column=1, sticky="e", padx=(0, 12))
        self._name_var = tk.StringVar(value=cur)
        ttk.Entry(row, textvariable=self._name_var, width=self._ENT_W).grid(
            row=0, column=2, sticky="e", padx=(0, 4))

        # language selector row
        lrow = tk.Frame(self._fields_frame, background=_R_BG_PANEL)
        lrow.pack(fill="x", pady=(0, 2))
        lrow.grid_columnconfigure(0, weight=1)
        self._wrap_label(lrow, t("Language"), _R_TEXT_DIM)
        self._name_lang_var = tk.StringVar(value=dic_mod.lang_label(start))
        cb = ttk.Combobox(lrow, textvariable=self._name_lang_var, state="readonly",
                          values=[dic_mod.lang_label(c) for c in langs], width=self._ENT_W - 2)
        cb.grid(row=0, column=2, sticky="e", padx=(0, 4))
        cb.bind("<<ComboboxSelected>>", lambda e: self._on_name_lang())

        tk.Label(self._fields_frame,
                 text=t("Pick a language, set the name, then pick another to set more — Apply commits "
                        "every language you changed into the mod's ZZ_Win.dat."),
                 background=_R_BG_PANEL, foreground=_R_TEXT_DIM, font=_F_MAIN, anchor="w",
                 justify="left", wraplength=520).pack(anchor="w", padx=2, pady=(0, 2))

    def _on_name_lang(self):
        """Language dropdown changed: stash what's typed for the old language, load the new one."""
        if self._name_var is None:
            return
        if self._name_cur_lang is not None:
            self._name_pending[self._name_cur_lang] = self._name_var.get()
        new_code = dic_mod.LANG_CODE.get(self._name_lang_var.get(), self._name_cur_lang)
        self._name_cur_lang = new_code
        orig = self._name_orig(new_code) or ""
        self._name_var.set(self._name_pending.get(new_code, orig))
        if self._name_cur_lbl is not None:
            self._name_cur_lbl.configure(text=orig[:self._VAL_W])

    def _render_upgrade(self, inst, d):
        self._upg_combo_var = None
        self._upg_candidates = {}
        self._upg_orig = None
        self._upg_isup_var = None
        self._upg_isup_orig = None
        self._upg_isup_chk = None
        self._upg_require_pidx = self._prop_index(inst.class_index, "UpgradeRequire")
        if d["kind"] != "unit" or self._upg_require_pidx is None:
            return
        ur_val = inst.get(self._upg_require_pidx)
        has_parent = ur_val is not None and ur_val.raw not in (None, 0)
        iu_val = self._prop_value(inst, "IsUpgrade")
        cur_isup = bool(iu_val.raw) if iu_val is not None else False
        cur = (str(self._ndf.resolve_value(ur_val)).replace("$obj:", "")
               if has_parent else _UPG_NONE)
        cands = {}
        for d2 in self._descs:
            if (d2 is not d and d2["kind"] == "unit"
                    and d2["nation"] == d["nation"] and d2["category"] == d["category"]):
                cands[d2["name"]] = (d2["inst_index"], d2["inst"].class_index)
        if has_parent:
            try:
                _m, (oi, ci) = ur_val.raw
                cands.setdefault(cur, (oi, ci))
            except Exception:
                pass
        self._upg_candidates = cands
        values = [_UPG_NONE] + sorted(cands.keys())

        self._section(self._fields_frame, t("Upgrade chain"))
        row0 = tk.Frame(self._fields_frame, background=_R_BG_PANEL)
        row0.pack(fill="x", pady=2)
        row0.grid_columnconfigure(0, weight=1)
        self._wrap_label(row0, t("Is an upgrade"), _R_TEXT)
        self._upg_isup_orig = cur_isup
        self._upg_isup_var = tk.BooleanVar(value=(True if has_parent else cur_isup))
        self._upg_isup_chk = tk.Checkbutton(
            row0, text=t("upgradable (adds price/time 50; hidden until researched)"),
            variable=self._upg_isup_var, background=_R_BG_PANEL, foreground=_R_TEXT,
            selectcolor=_R_BG_WIDGET, font=_F_MAIN, activebackground=_R_BG_PANEL,
            activeforeground=_R_GOLD_BRT)
        self._upg_isup_chk.grid(row=0, column=1, columnspan=2, sticky="e", padx=(0, 4))
        if has_parent:
            self._upg_isup_chk.configure(state="disabled")

        row = tk.Frame(self._fields_frame, background=_R_BG_PANEL)
        row.pack(fill="x", pady=2)
        row.grid_columnconfigure(0, weight=1)
        self._wrap_label(row, t("Upgrades from"), _R_TEXT)
        self._upg_combo_var = tk.StringVar(value=cur if cur in values else _UPG_NONE)
        self._upg_orig = self._upg_combo_var.get()
        combo = ttk.Combobox(row, textvariable=self._upg_combo_var, values=values, width=self._ENT_W,
                             state="readonly")
        combo.grid(row=0, column=2, sticky="e", padx=(0, 4))
        combo.bind("<<ComboboxSelected>>", lambda *_: self._on_upg_combo_change())

    def _on_upg_combo_change(self):
        if self._upg_isup_chk is None or self._upg_combo_var is None:
            return
        if self._upg_combo_var.get() != _UPG_NONE:
            self._upg_isup_var.set(True)
            self._upg_isup_chk.configure(state="disabled")
        else:
            self._upg_isup_chk.configure(state="normal")

    # ── Weapons tab ───────────────────────────────────────────────────────────

    def _wpn_label(self, a):
        # ammo's own name = its id (it has no readable name); users shown on selection
        return t("Ammo #{ammo_id}", ammo_id=a['id'])

    def _wpn_apply_filter(self):
        q = self._wpn_search_var.get().strip().lower()
        self._wpn_shown = []
        for a in self._ammo:
            hay = (str(a["id"]) + " " + " ".join(a["users"])).lower()
            if q and q not in hay:
                continue
            self._wpn_shown.append(a)
        self._wpn_lb.delete(0, tk.END)
        for a in self._wpn_shown:
            self._wpn_lb.insert(tk.END, self._wpn_label(a))
        self._wpn_count_lbl.configure(text=t("{shown} of {total}",
                                             shown=len(self._wpn_shown), total=len(self._ammo)))
        self._clear_wpn_fields()

    def _on_wpn_select(self, _=None):
        sel = self._wpn_lb.curselection()
        if not sel:
            return
        self._wpn_sel = self._wpn_shown[sel[0]]
        self._render_wpn_fields()

    def _clear_wpn_fields(self):
        for w in self._wpn_fields_frame.winfo_children():
            w.destroy()
        self._wpn_rows = []
        self._wpn_sel = None
        self._wpn_apply_btn.configure(state="disabled")
        self._wpn_dup_btn.configure(state="disabled")
        self._wpn_hdr.configure(text=t("Select a weapon"))
        self._wpn_sub.configure(text="")
        self._wpn_status.configure(text="")

    def _render_wpn_fields(self):
        for w in self._wpn_fields_frame.winfo_children():
            w.destroy()
        self._wpn_rows = []
        a = self._wpn_sel
        inst = a["inst"]
        self._wpn_hdr.configure(text=t("Ammo #{ammo_id}", ammo_id=a['id']))
        users = a["users"]
        self._wpn_sub.configure(
            text=(t("Used by: ") + (", ".join(users) if users else t("(no indexed unit)")))
            + (t("   — editing affects all of them") if len(users) > 1 else ""))
        self._col_header(self._wpn_fields_frame)
        self._render_group(self._wpn_fields_frame, self._wpn_rows, inst, _AMMO_FIELDS)
        self._section(self._wpn_fields_frame, t("Other ammo fields (raw)"))
        self._render_other(self._wpn_fields_frame, self._wpn_rows, inst,
                           {p for _, p, _ in _AMMO_FIELDS} | _OTHER_SKIP)
        self._wpn_apply_btn.configure(state="normal")
        self._wpn_dup_btn.configure(state="normal")
        self._wpn_status.configure(text="")

    def _apply_wpn(self):
        if self._wpn_sel is None:
            return
        changed, errors = self._commit_rows(self._wpn_rows)
        if errors:
            messagebox.showerror(t("Invalid value(s)"), "\n".join(errors), parent=self)
        if changed:
            self.project.mark_dirty("gameplay", mp_mod.EVERYTHING_PATH)
            self._keep_scroll(self._wpn_fields_frame, self._render_wpn_fields)  # show set values
            self._notify()
        self._wpn_status.configure(
            text=(t("Applied {n} change(s)", n=changed) if changed else t("No changes to apply")))

    # ── apply / commit ────────────────────────────────────────────────────────

    @staticmethod
    def _coerce(old, text):
        text = text.strip()
        if isinstance(old, bool):
            return text.lower() in ("1", "true", "yes", "on")
        if isinstance(old, float):
            return float(text)
        if isinstance(old, int):
            return int(float(text))
        return text

    def _commit_rows(self, rows):
        changed = 0
        errors = []
        for prop, kind, val, var, orig_str in rows:
            new_str = var.get().strip()
            if new_str == orig_str:
                continue
            try:
                if kind == "factory":
                    if new_str not in _TYPE_FACTORY:
                        errors.append(t("{prop}: unknown build menu '{value}'",
                                        prop=prop, value=new_str))
                        continue
                    val.raw = _TYPE_FACTORY[new_str]
                    changed += 1
                elif kind in ("list", "boollist"):
                    elems = val.raw
                    if not isinstance(elems, list) or not elems:
                        continue
                    parts = [p for p in (s.strip() for s in new_str.replace(";", ",").split(",")) if p]
                    if not parts:
                        continue

                    def conv(x):
                        return (x.lower() in ("1", "true", "yes", "on")) if kind == "boollist" else int(float(x))
                    if len(parts) == 1:
                        v0 = conv(parts[0])
                        for e in elems:
                            e.raw = v0
                    else:
                        for e, p in zip(elems, parts):
                            e.raw = conv(p)
                    changed += 1
                else:
                    val.raw = self._coerce(val.raw, new_str)
                    changed += 1
            except Exception as e:
                errors.append(t("{prop}: {e}", prop=prop, e=e))
        return changed, errors

    def _apply_edits(self):
        if not self._sel:
            return
        changed, errors = self._commit_rows(self._field_rows)

        # Upgrade chain: parent + independent IsUpgrade toggle; price/time follow IsUpgrade.
        if self._upg_combo_var is not None:
            sel = self._upg_combo_var.get()
            want_parent = sel != _UPG_NONE
            want_isup = True if want_parent else bool(self._upg_isup_var.get())
            if sel != self._upg_orig or want_isup != self._upg_isup_orig:
                try:
                    inst = self._sel["inst"]
                    if want_parent:
                        oi, ci = self._upg_candidates[sel]
                        inst.set(self._upg_require_pidx,
                                 ndfbin_mod.NdfValue(ndfbin_mod.T.Reference,
                                                     (ndfbin_mod.OBJ_REF_MARKER, (oi, ci))))
                    elif self._upg_require_pidx is not None and inst.get(self._upg_require_pidx) is not None:
                        inst.remove(self._upg_require_pidx)
                    self._set_bool_prop(inst, "IsUpgrade", want_isup)
                    if want_isup and not self._upg_isup_orig:
                        self._add_int_prop_if_missing(inst, "UpgradePrice", 50)
                        self._add_int_prop_if_missing(inst, "UpgradeTime", 50)
                    elif self._upg_isup_orig and not want_isup:
                        self._remove_prop(inst, "UpgradePrice")
                        self._remove_prop(inst, "UpgradeTime")
                    changed += 1
                except Exception as e:
                    errors.append(t("Upgrade: {e}", e=e))

        # Display name(s) — per-language edits in baseunite.dic (ZZ_Win.dat), tracked separately so a
        # name-only edit doesn't needlessly mark the gameplay dat dirty.
        name_changed = 0
        if self._name_var is not None and self._name_key is not None:
            if self._name_cur_lang is not None:        # capture the currently-shown language
                self._name_pending[self._name_cur_lang] = self._name_var.get()
            for lang, typed in self._name_pending.items():
                orig = self._name_orig(lang)
                if orig is None or typed == orig:
                    continue
                path = self._name_lang_paths.get(lang)
                try:
                    blob = self.project.get_raw("loc", path)
                    self.project.set_raw("loc", path, dic_mod.set_entry(blob, self._name_key, typed))
                    self._name_orig_by_lang[lang] = typed   # new baseline (so re-apply is a no-op)
                    name_changed += 1
                except Exception:
                    errors.append(t("Name [{lang}]: could not write into baseunite.dic",
                                    lang=dic_mod.lang_label(lang)))

        if errors:
            messagebox.showerror(t("Invalid value(s)"), "\n".join(errors), parent=self)
        if changed:
            self.project.mark_dirty("gameplay", mp_mod.EVERYTHING_PATH)
        if changed or name_changed:
            self._keep_scroll(self._fields_frame, self._render_fields)  # show set values
            self._notify()
        total = changed + name_changed
        self._status.configure(
            text=(t("Applied {total} change(s) · {pending} file(s) pending",
                    total=total, pending=self.project.dirty_count())
                  if total else t("No changes to apply")))

    def _notify(self):
        if self._on_change:
            try:
                self._on_change()
            except Exception:
                pass

    def _save_to_mod(self):
        # commit pending edits in whichever tab(s) have a selection first
        if self._sel and self._field_rows:
            self._apply_edits()
        if self._wpn_sel and self._wpn_rows:
            self._apply_wpn()
        if not self.project.is_dirty():
            messagebox.showinfo(t("Save mod"), t("No pending changes to save."), parent=self)
            return
        try:
            written = self.project.save_all()
        except Exception as e:
            messagebox.showerror(
                t("Save failed"),
                t("{e}\n\nTip: set the Game Root in Settings — it's needed to obtain the base "
                  "game file the first time a mod touches it.", e=e), parent=self)
            return
        self._notify()
        self._save_status.configure(text=t("Saved all changes to the mod"))
        messagebox.showinfo(t("Saved"), t("Saved all mod changes to:\n\n") + "\n".join(written),
                            parent=self)


# Standalone note (launched from the Mod Editor hub in mod_manager.py)
if __name__ == "__main__":
    print("UnitsEditorWindow is launched from the Mod Editor hub in mod_manager.py")
